# server.R
library(base64enc)
library(bitops)
library(RCurl)
library(RJSONIO)
library(ROAuth)
library(twitteR)
library(stringr)
library(ggplot2)
source("retArrivalTime.R")
api_key <- 'sjjI4w33PqZz6AR2noLKPziqT' 
api_secret <- 'ZmzBPig0L3KHEVEnS4PZ2PAwy0UsZNttDXTwqCfxhR2fBkZFqt'
token <- '2419123201-mv8GCAvaN3TQ6IgODq1XNyMbZIUxqO7Fc5WecG2' 
token_secret <- 'YCKkImPYyrseusHbCEebPuvmsOf00M5f9dIiWE5N6y3fU'
setup_twitter_oauth(api_key, api_secret, token, token_secret)



shinyServer(function(input, output) {
  observeEvent(input$goBabyGo, {
  output$plot <- renderPlot({
    total <- input$total
    timeout <- input$timeout
    
    
    list1 <- retArrivalTime(input$hash1, total, input$dates)
    dat1 <- as.data.frame(list1[2])
    
    list2 <- retArrivalTime(input$hash2, total, input$dates)
    dat2 <- as.data.frame(list2[2])
    
    list3 <- retArrivalTime(input$hash3, total, input$dates)
    dat3 <- as.data.frame(list3[2])
    
    ###################
    # ggplot CDF
    ####################
    dat <- rbind(dat1,dat2,dat3)
    
    
    
    # one
    p <- ggplot(data = dat, aes(x=x, y=y))+ 
      geom_line(aes(colour=legend))
    # two
    p <- p  +  xlab('Next Tweet Arrival Time in Seconds') +
      ylab('Cumulative Probability') +
      ggtitle('Arrival Time (1000 tweets) ')
    # three
    p <- p + geom_point(aes(colour=legend))
    # four
    p <- p + theme(axis.text=element_text(size=12),axis.title=element_text(size=13,face='bold'),plot.title= element_text(lineheight=.8,face="bold"),legend.text=element_text(size=13,face='bold'),legend.position='bottom')
    
    print(p)
  })
  #close the action button
  })
  
})