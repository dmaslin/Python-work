library(shiny)

shinyUI(fluidPage(
  titlePanel("TwitterCrawl"),
  
  sidebarLayout(
    sidebarPanel(
      helpText("Select the hashtags you wish to examine. 
               They will be plotted out on the chart to the right."),
    
      textInput("hash1", label = "First Hashtag", "#cookie"),
      textInput("hash2", label = "Second Hashtag", "#cake"),
      textInput("hash3", label = "Third Hashtag", "#pie"),
      numericInput("total", label = "Number of Tweets you want to try and get", 10, min = 10),
      dateRangeInput("dates", label = h3("Date range")),
    actionButton("goBabyGo", "Plot that!")),
      
    
    mainPanel(plotOutput("plot"))
  )
))